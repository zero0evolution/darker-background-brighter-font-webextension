
/*var init = function(){
	document.documentElement.style.setProperty("background-color","black")

	window.onbeforeunload = function(){
		document.documentElement.style.setProperty(
			"background-color","black")
	}
	window.onunload = function(){
		document.documentElement.style.setProperty(
			"background-color","black")
	}
	document.onpagehide = function(){
		document.documentElement.style.setProperty(
			"background-color","black")
	}
	document.onpageshow = function(){
		document.documentElement.style.setProperty(
			"background-color","black")
	}
	window.onabort = function(){
		document.documentElement.style.setProperty(
			"background-color","black")
	}
	document.onreadystatechange = function(){
		document.documentElement.style.setProperty(
			"background-color","black")
	}
}
if(optionInfo.changeColorFlag.value){
	// init()
}*/